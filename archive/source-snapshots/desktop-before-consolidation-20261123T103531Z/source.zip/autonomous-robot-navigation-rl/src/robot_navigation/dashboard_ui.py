"""Streamlit views; all quantitative displays read saved experiment evidence."""
import time

import pandas as pd
import streamlit as st

from .core import ACTION_NAMES, read_json
from .dashboard import evidence, early_checkpoint, frozen_episode, seek_from_widget, baseline_lineup, PART_A_SEEDS, comparison_rows
from .episodes import ComparisonPlayback, frame
from .interface import (context_strip, panel_heading, show_map, telemetry, run_label, SELECTED_RUN,
                        playback_toolbar, playback_status)
from .evidence import EXPECTED_ERRORS, checked_summary, check_pinned_summary, failure_state
from .release import final_summary
from .four_way import saved_summary as four_way_summary,STUDY as FOUR_WAY_STUDY
from .four_way_analysis import saved_analysis, ANALYSIS_STUDY
from .representation import saved_summary as representation_summary, STUDY as REPRESENTATION_STUDY


def saved_json(path):
    try:
        return read_json(path)
    except (OSError, ValueError) as exc:
        st.info(f'Saved evidence unavailable ({path.name}): {exc}')
        return None


def saved_image(path):
    if path.is_file():
        try:
            st.image(str(path), width='stretch')
        except OSError as exc:
            st.info(f'Saved figure unavailable: {path.name} ({exc})')
    else:
        st.info(f'Saved figure unavailable: {path.name}')


def saved_download(label,path,filename):
    try:
        data = path.read_bytes()
    except OSError as exc:
        st.info(f'{path.parent.name}: download unavailable ({path.name}: {exc}). Restore the named evidence file.')
        return
    st.download_button(label,data,file_name=filename,mime='text/csv')


def metric_rows(summary):
    rows=[]
    for name, system in summary['systems'].items():
        row={'System':name,'Seeds':system['seed_count']}
        for metric in ('success_rate','collision_rate','timeout_rate','spl','mean_successful_route_length','mean_return'):
            stats=system['aggregate'][metric]
            row[metric]=stats['mean']
            row[f'{metric} seed SD']=stats['sd']
        rows.append(row)
    return rows


def render_page(page, task, root):
    st.title(page)
    if page=='Unseen maps':
        from .unseen_ui import render_unseen
        render_unseen(root)
        return
    if page=='Methodology':
        render_methods(task)
        return
    if page=='Neural tuning':
        from .neural_tuning_ui import render_tuning
        render_tuning(task,root)
        return
    def optional(study, loader):
        try:
            value = loader(root)
            if value is None:
                st.info(f'{study}: unavailable. Restore its saved evidence files.')
                return None
            check_pinned_summary(root, study)
            return checked_summary(value, task)
        except EXPECTED_ERRORS as exc:
            st.info(f'{study}: {failure_state(exc)} ({exc}). Restore the reviewed study; other panels remain available.')
            return None

    representation = optional(REPRESENTATION_STUDY, representation_summary) if page in ('Learning analysis','Optimization and robustness') else None
    details = optional(ANALYSIS_STUDY, saved_analysis) if page in ('Agent comparison','Optimization and robustness') else None
    fourth = optional(FOUR_WAY_STUDY, four_way_summary) if page in ('Overview','Agent comparison','Learning analysis') else None
    if fourth and details and page=='Agent comparison':
        try:
            comparison_rows(fourth, details)
        except EXPECTED_ERRORS as exc:
            st.info(f'{ANALYSIS_STUDY}: unavailable for joining ({exc}). Showing baseline-only results.')
            details = None
    if page=='Agent comparison':
        st.subheader('Four RL algorithms: development validation')
        if fourth:
            st.caption('Historical Part A Q-learning, SARSA and DQN plus the additional PPO baseline. Five seeds and 200,000 training interactions per seed. Post-release exploratory comparison; PPO is not part of the frozen final evaluation below.')
            rows = comparison_rows(fourth, details)
            st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch')
            if details:
                st.caption('Route length is conditional on success: equal-weight seed means, excluding undefined zero-success seed means. Success counts span 928 scenarios × five seeds; they are not independent training replicates. Rates are fractions (1 = 100%).')
                st.subheader('Recorded costs across five training seeds')
                cost_labels = {'training_seconds':'Training seconds', 'evaluation_seconds':'Validation seconds',
                               'mean_decision_microseconds':'Decision microseconds', 'checkpoint_bytes':'Checkpoint bytes'}
                costs = [{'Algorithm': system['label'],
                          **{label: system['costs'][key]['mean'] for key, label in cost_labels.items()},
                          **{label+' seed SD': system['costs'][key]['sample_sd'] for key, label in cost_labels.items()}}
                         for system in details['systems'].values()]
                st.dataframe(pd.DataFrame(costs),hide_index=True,width='stretch')
                st.caption('Recorded timings are descriptive, from separate runs on this machine. Training excludes monitoring/export; validation includes reset/recording/export. Latency is the historical 100-query mean, excluding rendering. Checkpoint bytes exclude metadata and do not measure RAM. SD is sample SD across training seeds.')
                with st.expander('Per-seed metrics and recorded costs'):
                    records = [{'Algorithm': system['label'], 'Seed': seed['seed'],
                                'Run': seed['run_id'], 'Selected interaction': seed['selected_interactions'],
                                **{k:v for k,v in seed['metrics'].items() if k!='counts'}, **seed['costs']}
                               for system in details['systems'].values() for seed in system['seed_results']]
                    st.dataframe(pd.DataFrame(records),hide_index=True,width='stretch')
                    saved_download('Download four-algorithm metrics and costs',
                        root/'artifacts/studies'/ANALYSIS_STUDY/'costs.csv','four-rl-costs.csv')
            saved_image(root/'artifacts/studies'/FOUR_WAY_STUDY/'comparison.png')
        else:
            st.info('The PPO extension has not produced a verified four-algorithm comparison yet. The existing results below cover the original release.')
        st.divider()
    final = optional('final-v1', final_summary) if page in ('Overview','Agent comparison') else None
    st.caption(f"{task.grid.map_id} · {task.config['environment_version']} · development validation · "
               + ('inspected frozen final evaluation available' if final else 'final results unavailable on this page'))
    if final and page in ('Overview','Agent comparison'):
        task.check(final['signature'])
        st.subheader('Frozen final evaluation')
        st.caption('Held-out initial conditions on the same familiar map. All settings and checkpoints were frozen before this evaluation; no final-test selection. The simulator continues to use validation/custom scenarios.')
        final_rows=[{'System':name,'Replicates':system['replicates'],'Replicate unit':system['replicate_unit'],
                     **{m:system['metrics'][m]['mean'] for m in ('success_rate','collision_rate','timeout_rate','spl')}}
                    for name,system in final['systems'].items()]
        st.dataframe(pd.DataFrame(final_rows),hide_index=True,width='stretch')
        st.write(f"Predeclared selected system: **{final['selected_system']}**. It remains selected regardless of final ranking.")
        st.divider()
    try:
        summary=evidence(root)
        check_pinned_summary(root, 'milestone5-v1')
        checked_summary(summary, task)
    except EXPECTED_ERRORS as exc:
        st.info(f'Saved dashboard evidence unavailable: {exc}. Run developer/commands/analyze_core_robustness.py once with a fresh suite ID.')
        return
    study=root / 'artifacts/studies/milestone5-v1'
    if page=='Overview':
        st.write('A local research dashboard for coordinate-only navigation on one fixed map. Explore recorded decisions, compare frozen checkpoints and inspect weak scenario groups.')
        a,b,c=st.columns(3)
        a.metric('Implemented learned families','4')
        b.metric('Validation pairs per seed','928')
        c.metric('Trained RL families','4' if fourth else '3')
        st.dataframe(pd.DataFrame(metric_rows(summary))[['System','Seeds','success_rate','collision_rate','timeout_rate','spl']],hide_index=True,width='stretch')
        st.info('Q-learning improved with tuning. SARSA still misses its declared targets. Voting lost five goals versus its predeclared single member while improving SPL. Removing the step cost hurt both tabular families.')
        st.write('Use Navigation simulator for saved replay, a frozen custom demonstration, matched agents or early-versus-selected checkpoints. Learning analysis uses saved logs; Optimization and robustness shows outcome-independent scenario groups.')
        st.caption('Evidence is local under artifacts/studies/milestone5-v1. Original experiment snapshots and canonical benchmark files are unchanged.')
    elif page=='Learning analysis':
        if representation:
            st.subheader('DQN input representation: paired study')
            st.caption('Five fresh paired seeds; absolute inputs versus absolute plus relative goal offsets. Exploratory validation, unchanged task and DQN settings.')
            saved_image(root/'artifacts/studies'/REPRESENTATION_STUDY/'representation_learning.png')
        if fourth:
            st.subheader('Four-algorithm validation monitoring')
            st.caption('Additional PPO baseline alongside the original three Part A families; exploratory extension.')
            saved_image(root/'artifacts/studies'/FOUR_WAY_STUDY/'learning.png')
        st.write('Read-only 30-pair validation monitoring curves. The band is ±1 sample seed SD, clipped to [0,1]. Selected checkpoint results use the complete 928-pair validation set.')
        saved_image(study / 'figures/learning.png')
        names=[n for n,s in summary['systems'].items() if s['learning_curve']]
        name=st.selectbox('Learning system',names)
        frame=pd.DataFrame([{'interactions':r['interactions'],'success':r['success_rate']['mean'],
                             'success seed SD':r['success_rate']['sd'],'SPL':r['spl']['mean'],
                             'SPL seed SD':r['spl']['sd']} for r in summary['systems'][name]['learning_curve']])
        st.dataframe(frame,hide_index=True,width='stretch')
        st.dataframe(pd.DataFrame(summary['systems'][name]['seed_results']).drop(columns=['metrics']),hide_index=True,width='stretch')
    elif page=='Agent comparison':
        st.dataframe(pd.DataFrame(metric_rows(summary)),hide_index=True,width='stretch')
        st.caption('Rates use fractions (1 = 100%). Means and sample SD span five training seeds; voting is one fixed ensemble with no ensemble SD. DQN uses historical Part A seeds and is not a seed-matched Part B control.')
        name=st.selectbox('Inspect system',list(summary['systems']))
        rows=[]
        for seed in summary['systems'][name]['seed_results']:
            rows.append({k:v for k,v in {**seed,**seed['metrics']}.items() if k not in ('metrics','counts')})
        st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch')
        vote=saved_json(root / 'artifacts/studies/part-b-v1/voting_comparison.json')
        if vote is None:
            return
        st.write(f"Voting Q arrays: {vote['voting_table_memory_bytes']:,} bytes; single: {vote['single_table_memory_bytes']:,} bytes, excluding Python overhead. Member training: {vote['member_training_interactions']:,} interactions, already counted in Part B.")
        st.dataframe(pd.DataFrame([{'policy':k,**v} for k,v in vote['timing'].items()]),hide_index=True)
        st.caption('Above latency uses the shared 1,000-query benchmark. Per-run evaluation runtimes include reset/recording/export; they are local measurements, not isolated hardware guarantees. Voting wrapper training is zero, but member cost is not zero.')
    elif page=='Optimization and robustness':
        if representation:
            st.subheader('DQN input representation: controlled comparison')
            st.caption('Only input encoding changes: four absolute coordinates versus the same four plus two relative offsets. Five fresh paired seeds and 200k interactions each; no DQN tuning or new final evaluation. The six-input model has 128 additional online first-layer parameters.')
            rows=[{'Inputs':variant,'Seeds':system['seed_count'],
                   **{m:system['metrics'][m]['mean'] for m in ('success_rate','collision_rate','timeout_rate','spl')},
                   'Success seed SD':system['metrics']['success_rate']['sample_sd'],
                   'Online parameters':system['online_parameter_count'][0]}
                  for variant,system in representation['systems'].items()]
            st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch')
            st.caption('Relative minus control: paired training-seed differences. Rates are fractions; sample seed SD is not a confidence interval. No winner promotion follows this exploratory study.')
            st.dataframe(pd.DataFrame(representation['paired_seed_differences']),hide_index=True,width='stretch')
            saved_image(root/'artifacts/studies'/REPRESENTATION_STUDY/'paired_representation.png')
            st.divider()
        if details:
            st.subheader('Four baseline algorithms: fixed-map robustness')
            st.caption('Original Part A Q-learning, SARSA and DQN plus PPO; five seeds per family. Unchanged predefined geometry labels on development validation. These are exploratory, overlapping scenario dimensions on one familiar map, not causal effects or independent test sets.')
            dimensions = list(dict.fromkeys(g['dimension'] for g in details['systems']['ppo']['groups']))
            dimension = st.selectbox('Four-algorithm scenario dimension', dimensions, key='four_way_dimension')
            rows = []
            for system in details['systems'].values():
                for group in system['groups']:
                    if group['dimension'] == dimension:
                        route = group['metrics']['mean_successful_route_length']
                        rows.append({'Algorithm':system['label'],'Group':group['group'],
                                     'Pairs per seed':group['scenarios_per_seed'],'Seeds':system['seed_count'],
                                     **{m:group['metrics'][m]['mean'] for m in ('success_rate','collision_rate','timeout_rate','spl')},
                                     'Success seed SD':group['metrics']['success_rate']['sample_sd'],
                                     'Successful route actions':route['mean'],
                                     'Route contributing seeds':route['contributing_seeds'],
                                     'Successes across five seeds':group['counts']['success']})
            st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch',
                         column_config={'Group':st.column_config.TextColumn(width='medium')})
            st.caption('Each dimension partitions all 928 pairs per seed. Route means exclude zero-success seeds; an empty value means no successful routes, never a zero-action solution. Corridor labels describe the canonical BFS route. Groups differ in distance and geometry.')
            saved_download('Download four-algorithm robustness by seed',
                root/'artifacts/studies'/ANALYSIS_STUDY/'groups.csv','four-rl-robustness.csv')
            st.divider()
        st.subheader('Matched baseline versus refinement')
        paired=saved_json(root / 'artifacts/studies/part-b-v1/paired_improvements.json')
        if paired is not None:
            st.json(paired,expanded=False)
        st.caption('Original settings and tuned settings use the same fresh seeds and budgets. Hyperparameters were selected on separate development seeds. Reward-only ablation is diagnostic; returns across reward versions are not a quality ranking.')
        for filename in ('paired_refinement.png', 'reward_ablation.png', 'voting.png'):
            saved_image(root / 'artifacts/studies/part-b-v1/figures' / filename)
        st.subheader('Core robustness on the fixed map')
        st.write('Labels were fixed before aggregating learned outcomes. Each dimension partitions the same validation scenarios; dimensions overlap. Corridor means the canonical BFS route intersects a cell with exactly two opposite free neighbors, including endpoints. Near wall means the start has a blocked or out-of-bounds cardinal neighbor. Regions are map quadrants.')
        dimensions=list(dict.fromkeys(r['dimension'] for r in next(iter(summary['systems'].values()))['groups']))
        dimension=st.selectbox('Scenario dimension',dimensions)
        rows=[]
        for name,system in summary['systems'].items():
            for row in system['groups']:
                if row['dimension']==dimension:
                    rows.append({'System':name,'Group':row['group'],'Pairs per seed':row['scenarios_per_seed'],
                        'Seeds':system['seed_count'],**{m:row['aggregate'][m]['mean'] for m in ('success_rate','collision_rate','timeout_rate','spl')},
                        'success seed SD':row['aggregate']['success_rate']['sd']})
        st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch')
        saved_image(study / 'figures/distance.png')
        saved_image(study / 'figures/groups.png')
        st.caption('Per-seed group metrics, conditional successful route lengths/counts and seed-matched group deltas are retained in groups.csv, summary.json and paired_groups.json. Small groups and five seeds limit interpretation; no causal or unseen-state claim is made.')

    if page=='Optimization and robustness':
        from .recovery_ui import render_recovery
        render_recovery(root)


def overlays(prefix='single'):
    return {'trail':st.checkbox('Traveled trail',True,key=f'{prefix}_trail'),
            'visits':st.checkbox('Prefix visit counts',False,key=f'{prefix}_visits'),
            'bfs':st.checkbox('BFS planner reference',False,key=f'{prefix}_bfs')}


def diagnostics(episode,index,key):
    if episode.get('mode')=='training':
        st.caption('These are actual training actions, including exploration. The model could change during the episode. Decision scores were not recorded; the trained model is not used to fill them in.')
        return
    if index==0:
        st.caption('No action has been displayed. Decision scores are unavailable at the initial frame.')
        return
    transition=episode['transitions'][min(index,len(episode['transitions']))-1]
    st.caption(f'Recorded decision for displayed action {min(index,len(episode["transitions"]))}, at before-state {transition["observation"][:2]}. Scores describe the saved model output, not an explanation of reasoning.')
    if transition.get('scores') is not None:
        st.dataframe(pd.DataFrame({'Action':ACTION_NAMES,'Q score':transition['scores']}),hide_index=True)
        st.caption('Q-values are not probabilities.')
    elif transition.get('decision'):
        decision=transition['decision']
        if 'action_probabilities' in decision:
            st.dataframe(pd.DataFrame({'Action':ACTION_NAMES,'Action probability':decision['action_probabilities']}),hide_index=True)
            st.caption(f"PPO categorical action probabilities; selected action is the largest probability. State value: {decision['state_value']:.3f}. These are not Q-values.")
        else:
            st.json(decision)
    else:
        st.caption('Action scores unavailable for this policy.')


def event_log(episode,index,key,callback,disabled=False):
    # Prefix-only: selecting an event cannot reveal or draw future decisions.
    events=[{'Frame':0,'Action':'Initial state','Reward':0.,'Status':'ready'}]
    events += [{'Frame':i,'Action':ACTION_NAMES[t['action']],'Reward':t['reward'],'Status':t['info']['outcome']}
               for i,t in enumerate(episode['transitions'][:index],1)]
    st.dataframe(pd.DataFrame(events),hide_index=True,width='stretch')
    st.selectbox('Seek displayed event',range(index+1),index=index,key=key,on_change=callback,args=(key,),
                 format_func=lambda i:f'Frame {i}',disabled=disabled)
    if disabled:
        st.caption('Pause playback to seek a displayed event.')


def render_comparison(task,directory,validation,runs,root,four=False):
    with st.container(key='comparison_setup'):
        kind='Four baselines' if four else st.radio('Comparison type',['Different models','Earlier vs trained model'],horizontal=True,key='comparison_kind',
            help='Compare different saved models, or compare an early checkpoint against the same run after training.')
        fields=st.columns([1,2],gap='large')
        if four:
            training_seed=fields[0].selectbox('Training seed',PART_A_SEEDS,key='four_training_seed',
                help='Each seed identifies four baseline training runs, one per algorithm. Every run used 200,000 training steps.')
            st.caption('Four baseline models: Q-learning, SARSA, DQN and PPO. These are not four tuned models. Each panel shows one demonstration, not an overall ranking.')
        scenario=fields[1].selectbox('Start and goal',validation,
                             format_func=lambda s:f"{s['start']} → {s['goal']} · shortest {s['shortest_length']} steps",
                             key='comparison_scenario')
        second=directory
        early=None
        if four:
            try:
                lineup=baseline_lineup(training_seed,root)
            except (OSError,ValueError,KeyError) as exc:
                st.error(f'Four-agent lineup unavailable: {exc}')
                return
        elif kind=='Different models':
            preferred='m4-control-q-learning-seed101' if directory.name==SELECTED_RUN else SELECTED_RUN
            default=next((i for i,p in enumerate(runs) if p.name==preferred and p!=directory),
                         next((i for i,p in enumerate(runs) if p!=directory),0))
            second=fields[0].selectbox('Second trained model',runs,index=default,format_func=run_label,key='comparison_second')
        else:
            try:
                early=early_checkpoint(directory,root)
                fields[0].caption('Earlier model: saved at 10,000 training steps. Trained model: the checkpoint selected during training, which may precede the full budget.')
            except (OSError,ValueError) as exc:
                st.info(str(exc))
                return
        if not four:
            lineup=[directory,second]
    identity=(*map(str,lineup),scenario['id'],kind)
    if st.session_state.get('comparison_identity')!=identity:
        try:
            records=[frozen_episode(task,run,scenario,early if index==0 else None)
                     for index,run in enumerate(lineup)]
            st.session_state['comparison_playback']=ComparisonPlayback(records)
            st.session_state['comparison_identity']=identity
            st.session_state['comparison_seek']=0
            st.session_state['comparison_tick']=time.monotonic()
        except (OSError,ValueError,KeyError,RuntimeError,ImportError) as exc:
            st.error(f'Comparison unavailable: {exc}')
            return
    player=st.session_state['comparison_playback']
    options={'trail':st.session_state.get('comparison_trail',True),
             'visits':st.session_state.get('comparison_visits',False),
             'bfs':st.session_state.get('comparison_bfs',False)}
    with st.expander('About this comparison'):
        context_strip(player.episodes[0])
        st.caption('Frozen policies on validation scenarios. No learning or benchmark result writes.')
        st.caption('All panels share map, start, goal, reward, replay seed and action index. Finished agents hold their terminal frame.')
        st.caption('BFS knows the obstacle map. Learned agents see only robot and goal coordinates.')
    def command(name):
        player=st.session_state['comparison_playback']
        getattr(player,name)()
        st.session_state['comparison_playback']=player
        st.session_state['comparison_seek']=player.index
        st.session_state['comparison_tick']=time.monotonic()
        st.session_state['comparison_start_pending'] = name=='play'
    def seek(key):
        seek_from_widget(st.session_state, key, player_key='comparison_playback',
                         position_key='comparison_seek', active_key='comparison_timeline_key')
    with st.container(key='comparison_playback_controls'):
        speed=playback_toolbar(command,prefix='comparison_',speed_key='comparison_speed')
    @st.fragment(run_every=.2 if player.playing else None)
    def panels():
        if (st.session_state.get('replay_tab')!='Compare robots'
                or st.session_state.get('demo_map','bottleneck-v1')!='bottleneck-v1'
                or st.session_state.get('comparison_identity')!=identity):
            return
        player=st.session_state['comparison_playback']
        now=time.monotonic()
        # Start the clock from the first visible frame. Loading four models or
        # drawing their controls must not consume a move on the Play click.
        starting = st.session_state.pop('comparison_start_pending',False)
        if starting:
            st.session_state['comparison_tick'] = now
        if player.playing and not starting and now-st.session_state['comparison_tick']>=1/speed:
            player.tick()
            st.session_state['comparison_playback']=player
            st.session_state['comparison_seek']=player.index
            st.session_state['comparison_tick']=now
            if not player.playing:
                st.rerun()
        timeline_key=f'comparison-timeline:{identity}:{player.index}'
        st.session_state['comparison_timeline_key']=timeline_key
        st.slider('Replay position',0,player.length,value=player.index,key=timeline_key,
                  on_change=seek,args=(timeline_key,))
        playback_status(player.index,player.playing,shared=True)
        if four:
            with st.expander('Compare displayed steps'):
                rows=[]
                for episode,run in zip(player.episodes,lineup):
                    state=frame(episode,player.index)
                    rows.append({'Agent':run_label(run),'Episode state':state['status'].capitalize(),
                                 'Actions':state['index'],'Reward':round(state['return'],2),
                                 'Position':str(state['position'])})
                st.dataframe(pd.DataFrame(rows),hide_index=True,width='stretch')
                st.caption('These are the displayed episode prefixes, not aggregate validation rankings.')
        with st.container(key='four_maps' if four else 'pair_maps'):
            for offset in range(0,len(player.episodes),2):
                for panel_index,col in zip(range(offset,offset+2),st.columns(2,gap='medium')):
                    episode,run=player.episodes[panel_index],lineup[panel_index]
                    with col:
                        age='Early · 10,000 interactions' if early and panel_index==0 else 'Selected checkpoint'
                        panel_heading(run,f"{age} · replay seed {episode['seed']}")
                        show_map(task.grid,episode,player.index,view_key=f'comparison_map_3d_{panel_index}',**options)
                        telemetry(episode,player.index,task.config['max_steps'],player.playing,shared_index=player.index,compact=four)
                        with st.expander('Recorded decision and checkpoint'):
                            st.caption(episode['display_checkpoint'])
                            st.caption(episode['policy_id'])
                            diagnostics(episode,min(player.index,len(episode['transitions'])),'comparison')
    panels()
    with st.expander('Map display options'):
        overlays('comparison')


def render_methods(task=None):
    st.markdown('''The robot observes its row/column and goal row/column. Four discrete
actions move one cell. A wall or boundary attempt ends in collision; reaching the
goal ends in success; the cap of 200 actions truncates the episode. The original
reward is −0.01 per action, +10 at the goal and −5 on collision.

Q-learning and SARSA use coordinate-indexed tables. DQN scales the same four
coordinates by dimension minus one. BFS knows the obstacle map and supplies a
planner reference; learned agents receive no map, action mask or planner fallback.
The additional PPO baseline uses the same normalized coordinates, a categorical
four-action policy and separate actor/value networks. Its diagnostics are action
probabilities and a state-value estimate. It is a post-release exploratory
extension and is excluded from the original frozen final evaluation.
The separate DQN input study compares the original four absolute coordinates
with those coordinates plus two normalized goal offsets. Both receive the same
information; the six-input network has 128 more online first-layer parameters.
It is an exploratory input ablation, not a tuned replacement for historical DQN.
Voting uses three frozen Q-learning members, majority action and first-member
priority for three-way ties. Q-values are scores, never probabilities.

The saved train/validation/final manifests partition start–goal pairs on a familiar
map. States can overlap through training trajectories. Checkpoints and settings
were selected using development validation; these are not unseen-map or sealed
test results. The M6 final pairs have already been evaluated and inspected;
fixed-layout replay uses validation or custom routes, not new final evaluations.

Each learned run received 200,000 training interactions. Part A compared five
seeds per family. Part B spent an additional 12.4 million interactions across
search, controls, confirmations and reward ablations; voting reused three members.
Snapshots are inference-only and do not support exact training resume.

Success, collision and timeout partition completed episodes. SPL is success times
shortest distance / max(shortest distance, actions), averaged over every episode;
failures contribute zero. Successful route length is conditional on success and
must be read with its success count. Seed SD is sample SD, not a confidence interval.
Interactive demos/comparisons do not enter benchmark summaries.''')
    if task is not None:
        st.json(task.signature)
    st.caption('Protocol and full definitions: docs/milestone5_protocol.md. Final freeze/test is milestone 6. PPO is the additional fourth-algorithm extension. M10-M13 separately cover unseen layouts, frozen final evaluation and post hoc diagnosis. Hardware and dynamics noise remain outside this simulator.')
    st.subheader('Unseen layouts: separate benchmark')
    st.write('M11 trains on 12 layouts with four development layouts; M12 evaluates the frozen roster on ten different layouts (480 routes per policy). These final layouts are now inspected evidence. Q-learning and SARSA use 1,234 shared linear features; DQN and PPO use the same map-and-goal features before their networks. All four observe the full obstacle map. Three trained seeds per family; no final-data promotion.')
    st.write('BFS solves the fully known static grids optimally. Reinforcement learning is studied for learned decision-making and generalization, rather than claimed to outperform the planner. The M13 diagnosis describes cycles; it does not establish the cause or effectiveness of a recovery intervention.')
