"""Local bridge to the current application; no retired warehouse imports."""
from pathlib import Path
import runpy
import sys

CURRENT_APP = Path(__file__).resolve().parents[1] / ".runtime" / "newapp" / "autonomous-robot-navigation-rl"
sys.path.insert(0, str(CURRENT_APP / "src"))
runpy.run_path(str(CURRENT_APP / "app" / "streamlit_app.py"), run_name="__main__")
