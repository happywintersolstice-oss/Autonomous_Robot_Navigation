# Current application

Open `Robot Navigation.code-workspace` at the Desktop project root for the current application and guides. The old warehouse implementation and active test files were removed after archived copies were verified.

Use `py -3 run_app.py --check` from the Desktop root for an import check. Start the app with `Start Robot Navigation.cmd`. Historical experiments and validation evidence remain preserved in the current project archive.
