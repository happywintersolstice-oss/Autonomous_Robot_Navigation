"""Launch the current navigation app; the old Desktop warehouse app is retired."""
from pathlib import Path
import subprocess
import sys

CURRENT_PROJECT = Path(__file__).resolve().parent / "autonomous-robot-navigation-rl" / ".runtime" / "newapp"


def main():
    launcher = CURRENT_PROJECT / "run_app.py"
    if not launcher.is_file():
        print("The current project is missing. Open the updated main checkout instead of the retired warehouse app.")
        return 1
    try:
        return subprocess.call([sys.executable, str(launcher), *sys.argv[1:]], cwd=CURRENT_PROJECT)
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
